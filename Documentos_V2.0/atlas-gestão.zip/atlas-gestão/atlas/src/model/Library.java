package model;

import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.xdevapi.Client;

public class Library {

    private String libraryName;
    private int libraryId;
    private List<Client> clients;
    private List<Employee> employees;
    private List<Book> books;
    private String libraryAddress;
    private String libraryZipCode;
    private List<Copy> copies;
    private String libraryEmail;
    private String libraryPhone;

    public Library(String libraryName, int libraryId, String libraryAddress, String libraryZipCode,
        String libraryPhone, String libraryEmail) {
        this.libraryName = libraryName;
        this.libraryId = libraryId;
        this.libraryAddress = libraryAddress;
        this.libraryZipCode = libraryZipCode;
        this.libraryPhone = libraryPhone;
        this.libraryEmail = libraryEmail;

        this.clients = new ArrayList<>();
        this.employees = new ArrayList<>();
        this.books = new ArrayList<>();
        this.copies = new ArrayList<>();
    }

    public Library(String libraryName, String libraryAddress, String libraryZipCode) {
        this.libraryName = libraryName;
        this.libraryAddress = libraryAddress;
        this.libraryZipCode = libraryZipCode;

        this.clients = new ArrayList<>();
        this.employees = new ArrayList<>();
        this.books = new ArrayList<>();
        this.copies = new ArrayList<>();
    }

    public Library() {
        this.clients = new ArrayList<>();
        this.employees = new ArrayList<>();
        this.books = new ArrayList<>();
        this.copies = new ArrayList<>();
    }

    public String getLibraryName() {return libraryName;}
    public void setLibraryName(String libraryName) {
        this.libraryName = libraryName;
    }

    public int getLibraryId() {return libraryId;}
    public void setLibraryId(int libraryId) {
        this.libraryId = libraryId;
    }

    public List<Client> getClients() {return clients;}
    public void setClients(List<Client> clients) {
        this.clients = clients;
    }

    public List<Employee> getEmployees() {return employees;}
    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public List<Book> getBooks() {return books;}
    public void setBooks(List<Book> books) {this.books = books;}

    public String getLibraryAddress() {return libraryAddress;}
    public void setLibraryAddress(String libraryAddress) {
        this.libraryAddress = libraryAddress;
    }

    public String getLibraryZipCode() {return libraryZipCode;}
    public void setLibraryZipCode(String libraryZipCode) {
        this.libraryZipCode = libraryZipCode;
    }

    public List<Copy> getCopies() {return copies;}
    public void setCopies(List<Copy> copies) {
        this.copies = copies;
    }

    public String getLibraryEmail() {return libraryEmail;}
    public void setLibraryEmail(String libraryEmail) {
        this.libraryEmail = libraryEmail;
    }

    public String getLibraryPhone() {return libraryPhone;}
    public void setLibraryPhone(String libraryPhone) {
        this.libraryPhone = libraryPhone;
    }

    //OUTROS MÉTODOS
    public void addClient(Client c) {
        clients.add(c);
    }

    public void removeClient(String cpf) {
        //aki colocar a funcao que busca por cpf o cliente, ai ele vai e remove..
        clients.remove();
    }

    public Client findClientByCpf(String cpf) {
        return null;
    }

    public void addEmployee(Employee f) {
        employees.add(f);
    }

    public void removeEmployee(int id) {
    }

    public void addBook(Book l) {
    }

    public Book findBookByTitle(String title) {
        return null;
    }

    public List<Book> findBookByAuthor(String author) {
        return null;
    }

    public List<Book> findBookByCategory(String cat) {
        return null;
    }

    public List<Book> findBookBySubject(String subject) {
        return null;
    }

    public Book findBookById(int id) {
        return null;
    }
}


