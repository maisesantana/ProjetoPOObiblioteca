package view;
import controller.LibraryController;
public class LibraryView {
    
    private LibraryController lController;
    
    public void showInfo() {
    }
}
